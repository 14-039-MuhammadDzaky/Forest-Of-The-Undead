<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="outside" tilewidth="64" tileheight="64" tilecount="256" columns="12">
 <image source="../../asset/tilesets/outside.png" width="1024" height="1024"/>
</tileset>
