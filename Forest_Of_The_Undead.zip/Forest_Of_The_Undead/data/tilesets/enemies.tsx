<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="enemies" tilewidth="0" tileheight="0" tilecount="0" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
</tileset>
