<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="extra" tilewidth="64" tileheight="64" tilecount="66" columns="11">
 <image source="../../asset/tilesets/extra.png" width="704" height="384"/>
</tileset>
