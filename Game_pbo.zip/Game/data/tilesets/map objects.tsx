<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="map objects" tilewidth="100" tileheight="128" tilecount="7" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="100" height="128" source="../../graphics/map/objects/palm.png"/>
 </tile>
 <tile id="1">
  <image width="39" height="24" source="../../graphics/map/objects/grass1.png"/>
 </tile>
 <tile id="2">
  <image width="28" height="16" source="../../graphics/map/objects/grass2.png"/>
 </tile>
 <tile id="3">
  <image width="28" height="20" source="../../graphics/map/objects/grass3.png"/>
 </tile>
 <tile id="4">
  <image width="32" height="20" source="../../graphics/map/objects/grass4.png"/>
 </tile>
 <tile id="5">
  <image width="36" height="20" source="../../graphics/map/objects/grass5.png"/>
 </tile>
 <tile id="6">
  <image width="28" height="26" source="../../graphics/overworld/objects/stone.png"/>
 </tile>
</tileset>
