<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="grass" tilewidth="64" tileheight="64" tilecount="5" columns="5">
 <image source="../../graphics/tilesets/grass.png" width="320" height="64"/>
</tileset>
